function loadInterstitial() {

	var plc = document.getElementById('plc').value;

	clearStatus();
	updateStatus("loading plc: " + plc);

	window.AerServSDK.loadInterstitial(plc,
			function(){

				updateStatus("ad loaded");
				
			},
			function(){

				updateStatus("ad failed");
				
			},
			function(){

				updateStatus("ad shown");
				
			},
			function(){

				updateStatus("ad clicked");
				
			},
			function(){

				updateStatus("ad dismissed");
				
			}, "foo1,foo2");

}


function loadBanner() {

	var plc = document.getElementById('plc').value;
	clearStatus();
	updateStatus("loading plc: " + plc);

	window.AerServSDK.loadBanner(plc, 325, 50, AerServSDK.BANNER_BOTTOM,
			function(){

				updateStatus("ad loaded");
				
			},
			function(){

				updateStatus("ad failed");
				
			},
			function(){

				updateStatus("ad shown");
				
			},
			function(){

				updateStatus("ad clicked");
				
			},
			function(){

				updateStatus("ad dismissed");
				
			}, "foo1,foo2");

}

function killBanner() {

	window.AerServSDK.killBanner();

}

function updateStatus(message) {

	document.getElementById('status').innerHTML += message + "</br>";
	
}


function clearStatus() {
	
	document.getElementById('status').innerHTML = "";

}
